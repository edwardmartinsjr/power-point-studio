# Enterprise PowerPoint Design-System Knowledge Base

## Status

This reference file is included as the skill's knowledge base. The original linked `template.md` was not present in the supplied attachment, so this file preserves only the design-system guidance explicitly available in `design.md`. Replace this file with the full approved `template.md` when available, while keeping the same path: `references/template.md`.

## Visual language

- Anchor the system in graphite, white, gray, and signal green.
- Use accent colors consistently and sparingly.
- Use the organization-approved sans-serif. Use Arial or Aptos only when the approved font is unavailable.
- Maintain at least 11 pt body text.
- Use a shared grid, precise alignment, intentional asymmetry, and adequate negative space.
- Keep footers restrained and consistent for classification, slide number, and source.
- Keep short citations on slides and move long references to speaker notes or a references slide.

## Composition

- Give each slide one dominant visual argument.
- Favor editable vector compositions such as paths, networks, flows, matrices, timelines, or layered models.
- Prefer native PowerPoint shapes where practical.
- Avoid default SmartArt, decorative icon collections, grids of unrelated boxes, and long bullet lists.
- Use photography and screenshots only when they add evidence or narrative scale.

## Chart conventions

- State the intended takeaway for every chart.
- Highlight the relevant series or data point and mute secondary information.
- Use line charts for trends, bar charts for comparisons, bullet or variance charts for target gaps, stacked bars for composition, scatter plots for relationships, and maps only when geography is material.
- Use pie or donut charts only for a small number of categories.

## Accessibility and quality

- Ensure readable contrast and presentation-distance legibility.
- Do not rely on color alone for status cues.
- Check for overlap, clipping, overflow, inconsistent spacing, and low-resolution assets.
- Do not shrink text to compensate for overloaded slides.

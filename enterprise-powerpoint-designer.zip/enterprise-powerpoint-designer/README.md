# Enterprise PowerPoint Designer

This package is prepared for Microsoft 365 Copilot custom skills.

## Contents
- `SKILL.md`: required skill metadata and instructions
- `references/template.md`: design-system reference loaded when needed

## Upload
Upload `enterprise-powerpoint-designer.zip` in Microsoft 365 Copilot Agent Builder under the agent's Skills configuration.

The package contains no executable scripts. Presentation creation depends on the capabilities and tools available to the host agent.
